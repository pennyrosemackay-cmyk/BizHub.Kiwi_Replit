import { type User, type InsertUser, type Business, type InsertBusiness, type UpdateBusiness, users, businesses } from "@shared/schema";
import { db } from "../db";
import { eq, and, ilike, or, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Business operations
  getBusiness(id: string): Promise<Business | undefined>;
  getBusinessBySlug(slug: string): Promise<Business | undefined>;
  getBusinessesByUser(userId: string): Promise<Business[]>;
  getAllBusinesses(filters?: {
    category?: string;
    region?: string;
    search?: string;
  }): Promise<Business[]>;
  createBusiness(business: InsertBusiness): Promise<Business>;
  updateBusiness(id: string, updates: UpdateBusiness): Promise<Business | undefined>;
  deleteBusiness(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Business operations
  async getBusiness(id: string): Promise<Business | undefined> {
    const [business] = await db.select().from(businesses).where(eq(businesses.id, id));
    return business;
  }

  async getBusinessBySlug(slug: string): Promise<Business | undefined> {
    const [business] = await db.select().from(businesses).where(eq(businesses.slug, slug));
    return business;
  }

  async getBusinessesByUser(userId: string): Promise<Business[]> {
    return db.select().from(businesses).where(eq(businesses.userId, userId));
  }

  async getAllBusinesses(filters?: {
    category?: string;
    region?: string;
    search?: string;
  }): Promise<Business[]> {
    let query = db.select().from(businesses).where(eq(businesses.isActive, true));

    const conditions = [];

    if (filters?.category && filters.category !== "All Categories") {
      conditions.push(eq(businesses.category, filters.category));
    }

    if (filters?.region && filters.region !== "All New Zealand") {
      conditions.push(eq(businesses.region, filters.region));
    }

    if (filters?.search) {
      conditions.push(
        or(
          ilike(businesses.name, `%${filters.search}%`),
          ilike(businesses.description, `%${filters.search}%`)
        )
      );
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return query.orderBy(desc(businesses.createdAt));
  }

  async createBusiness(insertBusiness: InsertBusiness): Promise<Business> {
    // Generate slug from business name
    const slug = insertBusiness.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');

    const [business] = await db
      .insert(businesses)
      .values({ ...insertBusiness, slug })
      .returning();
    return business;
  }

  async updateBusiness(id: string, updates: UpdateBusiness): Promise<Business | undefined> {
    const [business] = await db
      .update(businesses)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(businesses.id, id))
      .returning();
    return business;
  }

  async deleteBusiness(id: string): Promise<boolean> {
    const result = await db.delete(businesses).where(eq(businesses.id, id));
    return result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();

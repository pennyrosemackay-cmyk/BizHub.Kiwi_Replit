import { useRoute } from "wouter";
import { Layout } from "@/components/layout";
import { MOCK_BUSINESSES } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Phone, Mail, Globe, Facebook, Instagram, Linkedin, Star, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BusinessProfile() {
  const [match, params] = useRoute("/business/:slug");
  const slug = params?.slug;
  const business = MOCK_BUSINESSES.find(b => b.slug === slug);
  const { toast } = useToast();

  if (!business) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-4xl font-serif font-bold mb-4">Business Not Found</h1>
          <p className="text-muted-foreground">The business you are looking for does not exist.</p>
          <Button className="mt-8" onClick={() => window.history.back()}>Go Back</Button>
        </div>
      </Layout>
    );
  }

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent!",
      description: `Your inquiry has been sent to ${business.name}.`,
    });
  };

  return (
    <Layout>
      {/* Hero Banner */}
      <div className="relative h-[40vh] md:h-[50vh] w-full overflow-hidden">
        <div className="absolute inset-0 bg-black/40 z-10" />
        <img 
          src={business.image} 
          alt={business.name} 
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-0 left-0 right-0 z-20 container mx-auto px-4 pb-8 md:pb-12 text-white">
          <div className="max-w-4xl">
            <Badge className="mb-4 bg-primary text-white hover:bg-primary border-none text-sm px-3 py-1">
              {business.category}
            </Badge>
            <h1 className="text-4xl md:text-6xl font-serif font-bold mb-2 shadow-sm">{business.name}</h1>
            <div className="flex flex-wrap items-center gap-4 text-sm md:text-base font-medium opacity-90">
              <span className="flex items-center gap-1"><MapPin size={16} /> {business.region}</span>
              <span className="flex items-center gap-1"><Star size={16} fill="currentColor" className="text-accent" /> {business.rating} ({business.reviewCount} Reviews)</span>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            
            {/* About */}
            <section>
              <h2 className="text-2xl font-serif font-bold mb-4">About Us</h2>
              <p className="text-lg leading-relaxed text-muted-foreground whitespace-pre-line">
                {business.about}
              </p>
            </section>

            {/* Services */}
            <section>
              <h2 className="text-2xl font-serif font-bold mb-6">Our Services</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {business.services.map((service, idx) => (
                  <Card key={idx} className="border-border/50 bg-secondary/20">
                    <CardContent className="p-4 flex items-start gap-3">
                      <CheckCircle2 className="text-primary mt-1 shrink-0" size={20} />
                      <span className="font-medium text-foreground">{service}</span>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            {/* Gallery */}
            <section>
              <h2 className="text-2xl font-serif font-bold mb-6">Gallery</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {business.gallery.map((img, idx) => (
                  <div key={idx} className="aspect-video rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all">
                    <img src={img} alt={`Gallery ${idx}`} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                  </div>
                ))}
              </div>
            </section>

          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Contact Info Card */}
            <Card className="shadow-md border-border/50 sticky top-24">
              <CardHeader>
                <CardTitle className="font-serif">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4 text-sm">
                  <div className="flex items-start gap-3">
                    <MapPin className="text-primary mt-1 shrink-0" size={18} />
                    <span className="text-muted-foreground">{business.address}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="text-primary shrink-0" size={18} />
                    <a href={`tel:${business.phone}`} className="hover:text-primary transition-colors">{business.phone}</a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="text-primary shrink-0" size={18} />
                    <a href={`mailto:${business.email}`} className="hover:text-primary transition-colors">{business.email}</a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Globe className="text-primary shrink-0" size={18} />
                    <a href={`https://${business.website}`} target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">{business.website}</a>
                  </div>
                </div>

                <Separator />

                <div className="flex justify-center gap-4">
                  {business.social.facebook && <a href={business.social.facebook} className="p-2 bg-secondary rounded-full hover:bg-primary hover:text-white transition-colors"><Facebook size={20} /></a>}
                  {business.social.instagram && <a href={business.social.instagram} className="p-2 bg-secondary rounded-full hover:bg-primary hover:text-white transition-colors"><Instagram size={20} /></a>}
                  {business.social.linkedin && <a href={business.social.linkedin} className="p-2 bg-secondary rounded-full hover:bg-primary hover:text-white transition-colors"><Linkedin size={20} /></a>}
                </div>

                <Separator />

                {/* Contact Form */}
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <h3 className="font-semibold text-sm">Send an inquiry</h3>
                  <Input placeholder="Your Name" required className="bg-background" />
                  <Input type="email" placeholder="Your Email" required className="bg-background" />
                  <Textarea placeholder="How can we help?" className="bg-background resize-none" rows={3} required />
                  <Button type="submit" className="w-full">Send Message</Button>
                </form>

              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}

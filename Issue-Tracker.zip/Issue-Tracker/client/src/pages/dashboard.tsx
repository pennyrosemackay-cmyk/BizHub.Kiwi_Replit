import { useState } from "react";
import { Link } from "wouter";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { BarChart, Users, Eye, CreditCard, Edit, LogOut } from "lucide-react";
import { MOCK_BUSINESSES } from "@/lib/mockData";
import { Logo } from "@/components/ui/logo";

export default function Dashboard() {
  // Simulate logged in user
  const business = MOCK_BUSINESSES[0]; 

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      {/* Dashboard Nav */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center hover:opacity-90 transition-opacity">
              <Logo />
            </Link>
            <span className="text-muted-foreground">|</span>
            <span className="font-medium">Dashboard</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground hidden md:inline">Welcome, {business.name}</span>
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive gap-2">
                <LogOut size={16} /> Sign Out
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Sidebar */}
          <div className="md:col-span-1 space-y-4">
            <Card className="border-border/50">
              <CardContent className="p-4 flex flex-col gap-2">
                <Button variant="secondary" className="justify-start">Overview</Button>
                <Button variant="ghost" className="justify-start">Edit Profile</Button>
                <Button variant="ghost" className="justify-start">Gallery</Button>
                <Button variant="ghost" className="justify-start">Subscription</Button>
                <Button variant="ghost" className="justify-start">Settings</Button>
              </CardContent>
            </Card>

            <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
              <h4 className="font-semibold text-sm mb-2">Your Profile is Live</h4>
              <p className="text-xs text-muted-foreground mb-3">Visitors can see your page at:</p>
              <Link href={`/business/${business.slug}`}>
                <a className="text-xs text-primary underline truncate block hover:text-primary/80" target="_blank">
                  /business/{business.slug}
                </a>
              </Link>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-3 space-y-8">
            
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Views</CardTitle>
                  <Eye className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">1,245</div>
                  <p className="text-xs text-muted-foreground">+20.1% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Inquiries</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">48</div>
                  <p className="text-xs text-muted-foreground">+12 new leads</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Subscription</CardTitle>
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">Active</div>
                  <p className="text-xs text-muted-foreground">Next billing: Dec 20, 2025</p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Edit Form */}
            <Card>
              <CardHeader>
                <CardTitle>Edit Profile Information</CardTitle>
                <CardDescription>Update your business details shown on your public page.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Business Name</Label>
                    <Input id="name" defaultValue={business.name} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Input id="category" defaultValue={business.category} disabled className="bg-muted" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="about">About</Label>
                  <Textarea id="about" defaultValue={business.about} rows={5} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input id="phone" defaultValue={business.phone} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" defaultValue={business.email} />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button>Save Changes</Button>
              </CardFooter>
            </Card>

          </div>
        </div>
      </div>
    </div>
  );
}

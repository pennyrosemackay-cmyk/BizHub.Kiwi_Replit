import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import cafeImg from '@assets/generated_images/modern_cafe_interior_with_coffee_machine.png';
import floristImg from '@assets/generated_images/florist_shop_front_with_colorful_flowers.png';
import plumberImg from '@assets/generated_images/plumber_working_in_modern_bathroom.png';
import yogaImg from '@assets/generated_images/yoga_studio_with_natural_light.png';
import bakeryImg from '@assets/generated_images/bakery_display_with_pastries.png';
import barberImg from '@assets/generated_images/barber_shop_with_vintage_chair.png';

// Duplicate images to create a longer scrolling effect
const IMAGES = [
  cafeImg, floristImg, plumberImg, yogaImg, bakeryImg, barberImg,
  cafeImg, floristImg, plumberImg, yogaImg, bakeryImg, barberImg,
  cafeImg, floristImg, plumberImg, yogaImg, bakeryImg, barberImg,
];

export function MasonryGrid() {
  // Create 3 columns of images
  const columns = [
    IMAGES.slice(0, 6),
    IMAGES.slice(6, 12),
    IMAGES.slice(12, 18),
  ];

  return (
    <div className="absolute inset-0 overflow-hidden z-0">
      <div className="grid grid-cols-3 gap-4 h-[120vh] -mt-10 mx-auto max-w-7xl px-4 opacity-100">
        {columns.map((col, i) => (
          <Column key={i} images={col} speed={i % 2 === 0 ? 30 : 45} direction={i % 2 === 0 ? -1 : 1} />
        ))}
      </div>
      {/* Gradient Overlay to fade out bottom and top */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-transparent to-background/80 z-10 pointer-events-none" />
      <div className="absolute inset-0 bg-black/10 backdrop-blur-[0px] z-10 pointer-events-none" />
    </div>
  );
}

function Column({ images, speed, direction }: { images: string[], speed: number, direction: number }) {
  const [y, setY] = useState(0);

  useEffect(() => {
    // Simple animation loop
    let animationFrameId: number;
    let currentY = 0;
    
    const animate = () => {
      currentY += (speed * 0.01) * direction;
      
      // Reset logic for infinite scroll illusion could be more complex, 
      // but for this prototype, let's just let it scroll or use CSS animation for smoother loop
      // Actually, let's switch to CSS animation for better performance in mockup
    };
    
    // animationFrameId = requestAnimationFrame(animate);
    // return () => cancelAnimationFrame(animationFrameId);
  }, [speed, direction]);

  return (
    <div className="flex flex-col gap-4 animate-scroll" style={{ 
      animationDuration: `${speed}s`,
      animationDirection: direction === 1 ? 'reverse' : 'normal' 
    }}>
      {/* Double the images for seamless loop */}
      {[...images, ...images].map((src, idx) => (
        <div key={idx} className="relative group overflow-hidden rounded-xl shadow-md bg-muted">
          <img 
            src={src} 
            alt="Business" 
            className="w-full h-auto object-cover transition-opacity duration-500 opacity-100"
          />
        </div>
      ))}
    </div>
  );
}

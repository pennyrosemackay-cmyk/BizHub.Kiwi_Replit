import React from 'react';
import { cn } from '@/lib/utils';

interface LogoProps {
  className?: string;
  textClassName?: string;
  showText?: boolean;
  iconOnly?: boolean;
}

export function Logo({ className, textClassName, showText = true, iconOnly = false }: LogoProps) {
  return (
    <div className={cn("flex items-center gap-3 select-none", className)}>
      {/* Icon Container */}
      <div className="relative w-10 h-10 flex items-center justify-center bg-primary rounded-lg shadow-sm shrink-0 overflow-hidden">
        <svg 
          viewBox="0 0 100 100" 
          className="w-8 h-8 text-white fill-current"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Building Block - Right side */}
          <rect x="62" y="55" width="24" height="30" rx="2" className="opacity-90" />
          <rect x="68" y="62" width="5" height="5" fill="var(--color-primary)" className="text-primary-foreground opacity-70" />
          <rect x="77" y="62" width="5" height="5" fill="var(--color-primary)" className="text-primary-foreground opacity-70" />
          <rect x="68" y="72" width="5" height="5" fill="var(--color-primary)" className="text-primary-foreground opacity-70" />
          <rect x="77" y="72" width="5" height="5" fill="var(--color-primary)" className="text-primary-foreground opacity-70" />
          
          {/* Kiwi Silhouette - Left side */}
          <path d="M48 35C55 35 60 40 62 45C62 45 75 52 85 58C85 58 82 60 78 60C72 56 65 52 62 52C62 65 55 75 42 75C28 75 22 65 22 55C22 42 32 35 48 35Z" />
          <path d="M35 75L32 85M45 75L48 85" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
        </svg>
      </div>

      {/* Text */}
      {!iconOnly && showText && (
        <span className={cn("font-serif font-bold text-2xl tracking-tight text-foreground", textClassName)}>
          BizHub<span className="text-primary">.</span>Kiwi
        </span>
      )}
    </div>
  );
}

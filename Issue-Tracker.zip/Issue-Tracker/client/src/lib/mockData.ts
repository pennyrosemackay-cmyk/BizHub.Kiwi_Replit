import cafeImg from '@assets/generated_images/modern_cafe_interior_with_coffee_machine.png';
import floristImg from '@assets/generated_images/florist_shop_front_with_colorful_flowers.png';
import plumberImg from '@assets/generated_images/plumber_working_in_modern_bathroom.png';
import yogaImg from '@assets/generated_images/yoga_studio_with_natural_light.png';
import bakeryImg from '@assets/generated_images/bakery_display_with_pastries.png';
import barberImg from '@assets/generated_images/barber_shop_with_vintage_chair.png';

export const CATEGORIES = [
  "All Categories",
  "Agriculture, Forestry & Fishing",
  "Automotive",
  "Community & Non-Profit",
  "Construction & Trades",
  "Education & Training",
  "Financial & Legal",
  "Health & Wellness",
  "Home & Lifestyle",
  "Hospitality & Tourism",
  "Manufacturing",
  "Media & Creative Industries",
  "Mining & Resources",
  "Personal Services",
  "Professional Services",
  "Real Estate & Property",
  "Retail",
  "Sports & Recreation",
  "Technology & IT",
  "Transport & Logistics"
];

export const REGIONS = [
  "All New Zealand",
  "Auckland",
  "Bay of Plenty",
  "Canterbury",
  "Gisborne",
  "Hawke's Bay",
  "Manawatu-Whanganui",
  "Marlborough",
  "Nelson",
  "Northland",
  "Otago",
  "Southland",
  "Taranaki",
  "Tasman",
  "Waikato",
  "Wellington",
  "West Coast"
];

export interface Business {
  id: string;
  slug: string;
  name: string;
  category: string;
  region: string;
  description: string;
  about: string;
  rating: number;
  reviewCount: number;
  image: string;
  phone: string;
  email: string;
  website: string;
  address: string;
  services: string[];
  social: {
    facebook?: string;
    instagram?: string;
    linkedin?: string;
  };
  template: 'A' | 'B' | 'C';
  gallery: string[];
}

export const MOCK_BUSINESSES: Business[] = [
  {
    id: "1",
    slug: "urban-brew-cafe",
    name: "Urban Brew Cafe",
    category: "Hospitality & Tourism",
    region: "Auckland",
    description: "Award-winning coffee and brunch spot in the heart of Ponsonby.",
    about: "Founded in 2015, Urban Brew Cafe has been serving Auckland's best coffee. We source our beans ethically and roast them locally. Our brunch menu features seasonal Kiwi produce.",
    rating: 4.8,
    reviewCount: 124,
    image: cafeImg,
    phone: "09 123 4567",
    email: "hello@urbanbrew.co.nz",
    website: "www.urbanbrew.co.nz",
    address: "123 Ponsonby Road, Auckland",
    services: ["Specialty Coffee", "All-day Brunch", "Catering", "Private Events"],
    social: {
      facebook: "#",
      instagram: "#"
    },
    template: "A",
    gallery: [cafeImg, bakeryImg, yogaImg]
  },
  {
    id: "2",
    slug: "blooms-botanicals",
    name: "Blooms Botanicals",
    category: "Retail",
    region: "Wellington",
    description: "Boutique florist specializing in native New Zealand arrangements.",
    about: "We believe in the power of flowers to brighten days. Specializing in native flora, we create stunning arrangements for weddings, events, and everyday gifts.",
    rating: 4.9,
    reviewCount: 89,
    image: floristImg,
    phone: "04 987 6543",
    email: "shop@blooms.co.nz",
    website: "www.blooms.co.nz",
    address: "45 Cuba Street, Wellington",
    services: ["Wedding Florals", "Gift Bouquets", "Corporate Events", "Workshops"],
    social: {
      instagram: "#",
      facebook: "#"
    },
    template: "B",
    gallery: [floristImg, yogaImg]
  },
  {
    id: "3",
    slug: "reliable-plumbing-nz",
    name: "Reliable Plumbing NZ",
    category: "Construction & Trades",
    region: "Waikato",
    description: "24/7 emergency plumbing services across the Waikato region.",
    about: "Family owned and operated for over 20 years. We handle everything from leaky taps to full bathroom renovations.",
    rating: 4.7,
    reviewCount: 210,
    image: plumberImg,
    phone: "07 555 1234",
    email: "admin@reliableplumbing.co.nz",
    website: "www.reliableplumbing.co.nz",
    address: "Serving Hamilton & Waikato",
    services: ["Emergency Repairs", "Renovations", "Gas Fitting", "Drain Unblocking"],
    social: {
      facebook: "#"
    },
    template: "C",
    gallery: [plumberImg]
  },
  {
    id: "4",
    slug: "zen-space-yoga",
    name: "Zen Space Yoga",
    category: "Health & Wellness",
    region: "Canterbury",
    description: "Peaceful sanctuary for yoga and meditation in Christchurch.",
    about: "Our studio offers a variety of classes for all levels. Connect with your breath and body in our light-filled space overlooking the park.",
    rating: 5.0,
    reviewCount: 56,
    image: yogaImg,
    phone: "03 333 4444",
    email: "namaste@zenspace.co.nz",
    website: "www.zenspace.co.nz",
    address: "88 Victoria Street, Christchurch",
    services: ["Vinyasa Flow", "Hatha Yoga", "Meditation", "Teacher Training"],
    social: {
      instagram: "#",
      facebook: "#"
    },
    template: "A",
    gallery: [yogaImg, cafeImg]
  },
  {
    id: "5",
    slug: "golden-crust-bakery",
    name: "Golden Crust Bakery",
    category: "Hospitality & Tourism",
    region: "Otago",
    description: "Famous pies and sourdough breads baked fresh daily.",
    about: "Using traditional recipes and local ingredients, we bake the best goods in Queenstown. Come in early before the almond croissants sell out!",
    rating: 4.6,
    reviewCount: 340,
    image: bakeryImg,
    phone: "03 442 9999",
    email: "orders@goldencrust.co.nz",
    website: "www.goldencrust.co.nz",
    address: "10 Shotover Street, Queenstown",
    services: ["Fresh Bread", "Pies & Pastries", "Coffee", "Celebration Cakes"],
    social: {
      instagram: "#",
      facebook: "#"
    },
    template: "B",
    gallery: [bakeryImg, cafeImg]
  },
  {
    id: "6",
    slug: "gentlemans-quarters",
    name: "Gentleman's Quarters",
    category: "Personal Services",
    region: "Auckland",
    description: "Premium barber shop offering cuts, shaves, and grooming.",
    about: "More than just a haircut, it's an experience. Sit back in our vintage chairs, enjoy a complimentary beverage, and let our master barbers take care of you.",
    rating: 4.8,
    reviewCount: 150,
    image: barberImg,
    phone: "09 555 8888",
    email: "book@gqbarbers.co.nz",
    website: "www.gqbarbers.co.nz",
    address: "20 High Street, Auckland CBD",
    services: ["Haircuts", "Hot Towel Shaves", "Beard Trims", "Grooming Products"],
    social: {
      instagram: "#",
      facebook: "#"
    },
    template: "C",
    gallery: [barberImg, plumberImg]
  }
];

import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin } from "lucide-react";
import { Business } from "@/lib/mockData";

export function BusinessCard({ business }: { business: Business }) {
  return (
    <Link href={`/business/${business.slug}`} className="block h-full group">
      <Card className="h-full overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-border/50 bg-card">
        <div className="relative aspect-[4/3] overflow-hidden">
          <img 
            src={business.image} 
            alt={business.name} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute top-3 left-3">
            <Badge variant="secondary" className="font-medium backdrop-blur-sm bg-white/90 text-primary hover:bg-white">
              {business.category}
            </Badge>
          </div>
        </div>
        
        <CardHeader className="pb-2">
          <div className="flex justify-between items-start mb-1">
            <h3 className="text-xl font-serif font-semibold group-hover:text-primary transition-colors line-clamp-1">
              {business.name}
            </h3>
          </div>
          <div className="flex items-center gap-1 text-accent">
            <Star size={14} fill="currentColor" />
            <span className="text-sm font-medium text-foreground">{business.rating}</span>
            <span className="text-xs text-muted-foreground">({business.reviewCount})</span>
          </div>
        </CardHeader>
        
        <CardContent className="pb-4">
          <p className="text-sm text-muted-foreground line-clamp-2">
            {business.description}
          </p>
        </CardContent>
        
        <CardFooter className="pt-0 text-xs text-muted-foreground flex items-center gap-1">
          <MapPin size={12} />
          {business.region}
        </CardFooter>
      </Card>
    </Link>
  );
}

import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { CATEGORIES, REGIONS } from "@/lib/mockData";
import { Upload, CheckCircle } from "lucide-react";
import { Combobox } from "@/components/ui/combobox";

export default function Onboarding() {
  const [location, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  
  // Form State
  const [category, setCategory] = useState("");
  const [region, setRegion] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setLocation("/dashboard");
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-muted/20 py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-serif font-bold text-foreground">Setup Your Business Profile</h1>
          <p className="text-muted-foreground">Tell us about your business so customers can find you.</p>
          
          {/* Progress Steps */}
          <div className="flex justify-center mt-6 gap-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className={`h-2 w-16 rounded-full transition-colors ${step >= i ? 'bg-primary' : 'bg-muted-foreground/20'}`} />
            ))}
          </div>
        </div>

        <Card className="shadow-lg border-border/60">
          <form onSubmit={handleSubmit}>
            {step === 1 && (
              <>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                  <CardDescription>Let's start with the essentials.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="businessName">Business Name</Label>
                    <Input id="businessName" placeholder="e.g. Joe's Coffee" required />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="category">Category</Label>
                      <Combobox 
                        items={CATEGORIES.filter(c => c !== "All Categories")}
                        value={category}
                        onValueChange={setCategory}
                        placeholder="Select Category"
                        searchPlaceholder="Search categories..."
                        className="h-10 bg-background border-input w-full"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="region">Region</Label>
                      <Combobox 
                        items={REGIONS.filter(r => r !== "All New Zealand")}
                        value={region}
                        onValueChange={setRegion}
                        placeholder="Select Region"
                        searchPlaceholder="Search regions..."
                        className="h-10 bg-background border-input w-full"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Physical Address</Label>
                    <Input id="address" placeholder="e.g. 123 Main St, Auckland" />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" placeholder="09 123 4567" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="website">Website (Optional)</Label>
                      <Input id="website" placeholder="www.example.co.nz" />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button type="button" onClick={() => setStep(2)}>Next Step</Button>
                </CardFooter>
              </>
            )}

            {step === 2 && (
              <>
                <CardHeader>
                  <CardTitle>Details & Media</CardTitle>
                  <CardDescription>Showcase what makes your business special.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="about">About Your Business</Label>
                    <Textarea id="about" placeholder="Tell your story..." className="min-h-[120px]" required />
                  </div>

                  <div className="space-y-2">
                    <Label>Logo & Images</Label>
                    <div className="border-2 border-dashed border-muted-foreground/30 rounded-lg p-8 text-center hover:bg-muted/30 transition-colors cursor-pointer">
                      <Upload className="mx-auto h-10 w-10 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground font-medium">Click to upload or drag and drop</p>
                      <p className="text-xs text-muted-foreground/70 mt-1">SVG, PNG, JPG (max 5MB)</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Social Media Links</Label>
                    <div className="grid grid-cols-1 gap-3">
                      <Input placeholder="Facebook URL" />
                      <Input placeholder="Instagram URL" />
                      <Input placeholder="LinkedIn URL" />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button type="button" variant="ghost" onClick={() => setStep(1)}>Back</Button>
                  <Button type="button" onClick={() => setStep(3)}>Next Step</Button>
                </CardFooter>
              </>
            )}

            {step === 3 && (
              <>
                <CardHeader>
                  <CardTitle>Choose Template</CardTitle>
                  <CardDescription>Select how your mini-site will look.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="border-2 border-primary rounded-lg p-4 cursor-pointer relative bg-secondary/10">
                      <div className="absolute top-2 right-2 text-primary"><CheckCircle size={20} fill="currentColor" className="text-white" /></div>
                      <div className="aspect-[3/4] bg-white rounded shadow-sm mb-3"></div>
                      <h3 className="font-semibold text-center">Modern</h3>
                    </div>
                    <div className="border border-border rounded-lg p-4 cursor-pointer hover:border-primary/50 transition-colors">
                      <div className="aspect-[3/4] bg-muted rounded shadow-sm mb-3"></div>
                      <h3 className="font-semibold text-center">Classic</h3>
                    </div>
                    <div className="border border-border rounded-lg p-4 cursor-pointer hover:border-primary/50 transition-colors">
                      <div className="aspect-[3/4] bg-muted rounded shadow-sm mb-3"></div>
                      <h3 className="font-semibold text-center">Minimal</h3>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button type="button" variant="ghost" onClick={() => setStep(2)}>Back</Button>
                  <Button type="submit" disabled={isLoading}>{isLoading ? "Creating Profile..." : "Complete Setup"}</Button>
                </CardFooter>
              </>
            )}
          </form>
        </Card>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { MasonryGrid } from "@/components/masonry-grid";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Search, MapPin, X } from "lucide-react";
import { CATEGORIES, REGIONS, MOCK_BUSINESSES } from "@/lib/mockData";
import { BusinessCard } from "@/components/business-card";
import { motion } from "framer-motion";
import { Combobox } from "@/components/ui/combobox";
import { Input } from "@/components/ui/input";

export default function Home() {
  const [location, setLocation] = useLocation();
  const [selectedRegion, setSelectedRegion] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [searchKeyword, setSearchKeyword] = useState("");

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (selectedRegion && selectedRegion !== "All New Zealand") params.append("region", selectedRegion);
    if (selectedCategory && selectedCategory !== "All Categories") params.append("category", selectedCategory);
    if (searchKeyword) params.append("search", searchKeyword);
    setLocation(`/search?${params.toString()}`);
  };

  const featuredBusinesses = MOCK_BUSINESSES.slice(0, 3);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Background */}
        <MasonryGrid />
        
        {/* Content */}
        <div className="relative z-20 container mx-auto px-4 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-4xl mx-auto space-y-8"
          >
            <h1 className="text-5xl md:text-7xl font-bold font-serif text-white drop-shadow-2xl leading-tight">
              Discover Local <br/>
              <span className="text-primary bg-white/95 px-4 pt-2 pb-1 rounded-xl shadow-lg inline-block transform -rotate-2 mt-2">Kiwi Businesses</span>
            </h1>

            <div className="mt-6">
              <span className="text-xl font-bold text-black bg-white/90 px-6 py-2 rounded-full shadow-md backdrop-blur-sm">
                Powered by Locals, for Locals
              </span>
            </div>
            
            {/* Search Box */}
            <Card className="max-w-4xl mx-auto border-0 shadow-2xl bg-white/95 backdrop-blur-xl p-2 mt-8">
              <CardContent className="p-2 md:p-4">
                <div className="flex flex-col gap-4">
                  {/* Keyword Search Row */}
                  <div className="relative w-full">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                    <Input 
                      placeholder="Search by name or keyword..." 
                      className="pl-10 pr-10 h-12 bg-secondary/30 border-transparent text-base"
                      value={searchKeyword}
                      onChange={(e) => setSearchKeyword(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                      data-testid="input-search-keyword"
                    />
                    {searchKeyword && (
                      <button
                        onClick={() => setSearchKeyword("")}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 rounded-full hover:bg-muted flex items-center justify-center"
                        data-testid="button-clear-keyword"
                      >
                        <X className="h-3 w-3 text-muted-foreground" />
                      </button>
                    )}
                  </div>
                  
                  {/* Filters Row */}
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-1">
                      <Combobox 
                        items={REGIONS}
                        value={selectedRegion}
                        onValueChange={setSelectedRegion}
                        placeholder="Search NZ Region"
                        searchPlaceholder="Search regions..."
                        icon={<MapPin size={18} />}
                      />
                    </div>

                    <div className="flex-1">
                      <Combobox 
                        items={CATEGORIES}
                        value={selectedCategory}
                        onValueChange={setSelectedCategory}
                        placeholder="What are you looking for?"
                        searchPlaceholder="Search categories..."
                        icon={<Search size={18} />}
                      />
                    </div>

                    <Button 
                      size="lg" 
                      className="h-12 px-8 text-base font-semibold shadow-md bg-primary hover:bg-primary/90 text-white"
                      onClick={handleSearch}
                      data-testid="button-search"
                    >
                      Search
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <p className="text-xl md:text-2xl text-foreground/90 font-medium max-w-2xl mx-auto bg-white/80 backdrop-blur-md p-4 rounded-lg shadow-sm mt-8">
              Search by category & location. Explore mini-websites for 10,000+ Kiwi businesses.
            </p>

            <div className="flex flex-wrap justify-center gap-3 text-sm font-medium text-foreground/70 pt-4">
              <span>Popular:</span>
              <button onClick={() => setLocation('/search?category=Hospitality+%26+Tourism')} className="hover:text-primary underline decoration-dotted">Cafes</button>
              <button onClick={() => setLocation('/search?category=Construction+%26+Trades')} className="hover:text-primary underline decoration-dotted">Plumbers</button>
              <button onClick={() => setLocation('/search?category=Retail')} className="hover:text-primary underline decoration-dotted">Florists</button>
              <button onClick={() => setLocation('/search?category=Health+%26+Wellness')} className="hover:text-primary underline decoration-dotted">Yoga</button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Section */}
      <section className="py-24 bg-secondary/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">Featured Local Gems</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Hand-picked businesses that our community loves.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredBusinesses.map((business) => (
              <BusinessCard key={business.id} business={business} />
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button variant="outline" size="lg" className="border-primary text-primary hover:bg-primary hover:text-white" onClick={() => setLocation('/search')}>
              View All Businesses
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}

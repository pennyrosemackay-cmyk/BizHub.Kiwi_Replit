import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";

export default function Subscribe() {
  const [location, setLocation] = useLocation();

  const handleSubscribe = () => {
    // Simulate Stripe Redirect
    setLocation("/onboarding");
  };

  return (
    <div className="min-h-screen bg-muted/20 flex flex-col items-center py-20 px-4">
      <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
        <h1 className="text-4xl font-serif font-bold text-foreground">Choose Your Plan</h1>
        <p className="text-muted-foreground text-lg">
          Simple, transparent pricing. No hidden fees. Cancel anytime.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
        {/* Monthly Plan */}
        <Card className="border-2 border-border/50 shadow-sm hover:border-primary/50 transition-colors relative overflow-hidden">
          <CardHeader>
            <CardTitle className="text-2xl font-serif">Monthly</CardTitle>
            <CardDescription>Perfect for small businesses starting out</CardDescription>
            <div className="mt-4">
              <span className="text-4xl font-bold">$29</span>
              <span className="text-muted-foreground"> / month</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2"><Check className="text-primary h-5 w-5" /> Detailed Business Profile</li>
              <li className="flex items-center gap-2"><Check className="text-primary h-5 w-5" /> Image Gallery (up to 5 photos)</li>
              <li className="flex items-center gap-2"><Check className="text-primary h-5 w-5" /> Contact Form Integration</li>
              <li className="flex items-center gap-2"><Check className="text-primary h-5 w-5" /> Basic Analytics</li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button className="w-full" variant="outline" onClick={handleSubscribe}>Select Monthly</Button>
          </CardFooter>
        </Card>

        {/* Yearly Plan */}
        <Card className="border-2 border-primary shadow-xl relative overflow-hidden bg-background">
          <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-bl-lg">
            BEST VALUE
          </div>
          <CardHeader>
            <CardTitle className="text-2xl font-serif">Yearly</CardTitle>
            <CardDescription>Save 20% with annual billing</CardDescription>
            <div className="mt-4">
              <span className="text-4xl font-bold">$290</span>
              <span className="text-muted-foreground"> / year</span>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2"><Check className="text-primary h-5 w-5" /> <strong>Everything in Monthly</strong></li>
              <li className="flex items-center gap-2"><Check className="text-primary h-5 w-5" /> Priority Search Listing</li>
              <li className="flex items-center gap-2"><Check className="text-primary h-5 w-5" /> Unlimited Image Gallery</li>
              <li className="flex items-center gap-2"><Check className="text-primary h-5 w-5" /> Verified Badge</li>
              <li className="flex items-center gap-2"><Check className="text-primary h-5 w-5" /> 2 Months Free</li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button className="w-full bg-primary hover:bg-primary/90" size="lg" onClick={handleSubscribe}>Select Yearly</Button>
          </CardFooter>
        </Card>
      </div>

      <div className="mt-12 text-center text-sm text-muted-foreground">
        <Link href="/" className="hover:text-primary underline">
          Back to Home
        </Link>
      </div>
    </div>
  );
}

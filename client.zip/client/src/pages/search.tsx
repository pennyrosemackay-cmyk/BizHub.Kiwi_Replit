import { useEffect, useState } from "react";
import { useLocation, useSearch } from "wouter";
import { Layout } from "@/components/layout";
import { BusinessCard } from "@/components/business-card";
import { CATEGORIES, REGIONS, MOCK_BUSINESSES } from "@/lib/mockData";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search as SearchIcon, MapPin, SlidersHorizontal, X } from "lucide-react";
import { Combobox } from "@/components/ui/combobox";

export default function SearchPage() {
  const [location] = useLocation();
  const searchString = useSearch(); // Returns query string like "region=Auckland&category=Hospitality"
  
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRegion, setSelectedRegion] = useState("All New Zealand");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  
  // Parse initial query params
  useEffect(() => {
    const params = new URLSearchParams(searchString);
    const regionParam = params.get("region");
    const categoryParam = params.get("category");
    const searchParam = params.get("search");
    
    if (regionParam && REGIONS.includes(regionParam)) setSelectedRegion(regionParam);
    if (categoryParam && CATEGORIES.includes(categoryParam)) setSelectedCategory(categoryParam);
    if (searchParam) setSearchTerm(searchParam);
  }, [searchString]);

  // Filter businesses
  const filteredBusinesses = MOCK_BUSINESSES.filter(business => {
    const matchesRegion = selectedRegion === "All New Zealand" || business.region === selectedRegion;
    const matchesCategory = selectedCategory === "All Categories" || business.category === selectedCategory;
    const matchesSearch = searchTerm === "" || 
      business.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      business.description.toLowerCase().includes(searchTerm.toLowerCase());
      
    return matchesRegion && matchesCategory && matchesSearch;
  });

  return (
    <Layout>
      <div className="bg-muted/30 border-b border-border">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-serif font-bold mb-6">Find Local Businesses</h1>
          
          {/* Filters Bar */}
          <div className="bg-card rounded-lg shadow-sm p-4 flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1 w-full">
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                placeholder="Search by name or keyword..." 
                className="pl-9 pr-9 bg-background"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="input-search-term"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm("")}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 rounded-full hover:bg-muted flex items-center justify-center"
                  data-testid="button-clear-search"
                >
                  <X className="h-3 w-3 text-muted-foreground" />
                </button>
              )}
            </div>
            
            <div className="w-full md:w-48">
              <Combobox 
                items={REGIONS}
                value={selectedRegion}
                onValueChange={setSelectedRegion}
                placeholder="Region"
                searchPlaceholder="Search regions..."
                icon={<MapPin className="h-4 w-4 text-muted-foreground" />}
                className="h-10 bg-background border-input"
                defaultValue="All New Zealand"
              />
            </div>

            <div className="w-full md:w-48">
              <Combobox 
                items={CATEGORIES}
                value={selectedCategory}
                onValueChange={setSelectedCategory}
                placeholder="Category"
                searchPlaceholder="Search categories..."
                icon={<SlidersHorizontal className="h-4 w-4 text-muted-foreground" />}
                className="h-10 bg-background border-input"
                defaultValue="All Categories"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="mb-6 flex justify-between items-center">
          <p className="text-muted-foreground">
            Showing <span className="font-semibold text-foreground">{filteredBusinesses.length}</span> results
          </p>
        </div>

        {filteredBusinesses.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredBusinesses.map((business) => (
              <BusinessCard key={business.id} business={business} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-muted/20 rounded-xl">
            <div className="text-4xl mb-4">🥝</div>
            <h3 className="text-xl font-bold mb-2">No businesses found</h3>
            <p className="text-muted-foreground">Try adjusting your filters or search term.</p>
            <Button 
              variant="link" 
              onClick={() => {
                setSelectedRegion("All New Zealand");
                setSelectedCategory("All Categories");
                setSearchTerm("");
              }}
            >
              Clear all filters
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}
